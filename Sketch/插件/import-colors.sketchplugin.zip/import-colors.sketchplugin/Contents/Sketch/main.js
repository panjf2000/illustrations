var that = this;
function __skpm_run (key, context) {
  that.context = context;

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/main.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/@skpm/dialog/lib/index.js":
/*!************************************************!*\
  !*** ./node_modules/@skpm/dialog/lib/index.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* let's try to match the API from Electron's Dialog
(https://github.com/electron/electron/blob/master/docs/api/dialog.md) */

module.exports = {
  showOpenDialog: __webpack_require__(/*! ./open-dialog */ "./node_modules/@skpm/dialog/lib/open-dialog.js"),
  showSaveDialog: __webpack_require__(/*! ./save-dialog */ "./node_modules/@skpm/dialog/lib/save-dialog.js"),
  showMessageBox: __webpack_require__(/*! ./message-box */ "./node_modules/@skpm/dialog/lib/message-box.js"),
  // showErrorBox: require('./error-box'),
}


/***/ }),

/***/ "./node_modules/@skpm/dialog/lib/message-box.js":
/*!******************************************************!*\
  !*** ./node_modules/@skpm/dialog/lib/message-box.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable no-not-accumulator-reassign/no-not-accumulator-reassign */
var RunDelegate = __webpack_require__(/*! ./run-delegate */ "./node_modules/@skpm/dialog/lib/run-delegate.js")

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowmessageboxbrowserwindow-options-callback
var typeMap = {
  none: 0,
  info: 1,
  error: 2,
  question: 1,
  warning: 2,
}
module.exports = function messageBox(document, options, callback) {
  if (!document ||
    (typeof document.class !== 'function' && !document.sketchObject)
  ) {
    callback = options
    options = document
    document = undefined
  } else if (document.sketchObject) {
    document = document.sketchObject
  }
  if (!options) {
    options = {}
  }

  var response

  var dialog = NSAlert.alloc().init()

  if (options.type) {
    dialog.alertStyle = typeMap[options.type] || 0
  }

  if (options.buttons && options.buttons.length) {
    options.buttons.forEach(function addButton(button) {
      dialog.addButtonWithTitle(
        options.normalizeAccessKeys ? button.replace(/&/g, '') : button
      )
      // TODO: add keyboard shortcut if options.normalizeAccessKeys
    })
  }

  if (typeof options.defaultId !== 'undefined') {
    var buttons = dialog.buttons()
    if (options.defaultId < buttons.length) {
      // Focus the button at defaultId if the user opted to do so.
      // The first button added gets set as the default selected.
      // So remove that default, and make the requested button the default.
      buttons[0].setKeyEquivalent('')
      buttons[options.defaultId].setKeyEquivalent('\r')
    }
  }

  if (options.title) {
    // not shown on macOS
  }

  if (options.message) {
    dialog.messageText = options.message
  }

  if (options.detail) {
    dialog.informativeText = options.detail
  }

  if (options.checkboxLabel) {
    dialog.showsSuppressionButton = true
    dialog.suppressionButton().title = options.checkboxLabel

    if (typeof options.checkboxChecked !== 'undefined') {
      dialog.suppressionButton().state = options.checkboxChecked ?
        NSOnState :
        NSOffState
    }
  }

  if (options.icon) {
    if (typeof options.icon === 'string') {
      options.icon = NSImage.alloc().initWithContentsOfFile(options.icon)
    }
    dialog.icon = options.icon
  } else if (
    typeof __command !== 'undefined' &&
    __command.pluginBundle() &&
    __command.pluginBundle().icon()
  ) {
    dialog.icon = __command.pluginBundle().icon()
  } else {
    var icon = NSImage.imageNamed('plugins')
    if (icon) {
      dialog.icon = icon
    }
  }

  if (!document) {
    response = Number(dialog.runModal()) - 1000
    if (callback) {
      var checkboxChecked = false
      if (options.checkboxLabel) {
        checkboxChecked = dialog.suppressionButton().state() == NSOnState
      }
      callback({
        response: response,
        checkboxChecked: checkboxChecked,
      })
      return undefined
    }
    return response
  }

  var delegate = RunDelegate.new()

  dialog.buttons().forEach(function hookButton(button, i) {
    button.setTarget(delegate)
    button.setAction(NSSelectorFromString('buttonClicked:'))
    button.setTag(i)
  })

  var fiber
  if (callback) {
    if (coscript.createFiber) {
      fiber = coscript.createFiber()
    } else {
      coscript.shouldKeepAround = true
    }
  }

  delegate.options = NSDictionary.dictionaryWithDictionary({
    onClicked: function handleEnd(returnCode) {
      if (callback) {
        callback({
          response: Number(returnCode),
          checkboxChecked: dialog.suppressionButton().state() == NSOnState,
        })
        NSApp.endSheet(dialog.window())
        if (fiber) {
          fiber.cleanup()
        } else {
          coscript.shouldKeepAround = false
        }
      } else {
        NSApp.stopModalWithCode(Number(returnCode))
      }
    },
  })

  var window = (document.sketchObject || document).documentWindow()
  dialog.beginSheetModalForWindow_modalDelegate_didEndSelector_contextInfo(
    window,
    null,
    null,
    null
  )

  if (!callback) {
    response = Number(NSApp.runModalForWindow(window))
    NSApp.endSheet(dialog.window())
    return response
  }

  return undefined
}


/***/ }),

/***/ "./node_modules/@skpm/dialog/lib/open-dialog.js":
/*!******************************************************!*\
  !*** ./node_modules/@skpm/dialog/lib/open-dialog.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable no-not-accumulator-reassign/no-not-accumulator-reassign */
var RunDelegate = __webpack_require__(/*! ./run-delegate */ "./node_modules/@skpm/dialog/lib/run-delegate.js")
var utils = __webpack_require__(/*! ./utils */ "./node_modules/@skpm/dialog/lib/utils.js")

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowopendialogbrowserwindow-options-callback
module.exports = function openDialog(document, options, callback) {
  if (!document || typeof document.class !== 'function') {
    callback = options
    options = document
    document = undefined
  }
  if (!options) {
    options = {}
  }

  var dialog = NSOpenPanel.openPanel()

  if (options.title) {
    dialog.title = options.title
  }

  if (options.defaultPath) {
    dialog.setDirectoryURL(utils.getURL(options.defaultPath))
  }

  if (options.buttonLabel) {
    dialog.prompt = options.buttonLabel
  }

  if (options.filters && options.filters.length) {
    var exts = []
    options.filters.forEach(function setFilter(filter) {
      filter.extensions.forEach(function setExtension(ext) {
        exts.push(ext)
      })
    })

    dialog.allowedFileTypes = exts
  }

  if (options.properties && options.properties.length) {
    options.properties.forEach(function setProperty(p) {
      if (p === 'openFile') {
        dialog.canChooseFiles = true
      } else if (p === 'openDirectory') {
        dialog.canChooseDirectories = true
      } else if (p === 'multiSelections') {
        dialog.allowsMultipleSelection = true
      } else if (p === 'showHiddenFiles') {
        dialog.showsHiddenFiles = true
      } else if (p === 'createDirectory') {
        dialog.createDirectory = true
      } else if (p === 'noResolveAliases') {
        dialog.resolvesAliases = false
      } else if (p === 'treatPackageAsDirectory') {
        dialog.treatsFilePackagesAsDirectories = true
      }
    })
  }

  if (options.message) {
    dialog.message = options.message
  }

  var buttonClicked

  function getURLs() {
    var result = []
    var urls = dialog.URLs()
    for (var k = 0; k < urls.length; k += 1) {
      result.push(String(urls[k].path()))
    }

    return result
  }

  if (!document) {
    buttonClicked = dialog.runModal()
    if (buttonClicked == NSOKButton) {
      if (callback) {
        callback(getURLs())
        return undefined
      }
      return getURLs()
    }

    return []
  }

  var nsButtonClass = NSButton.class()

  function findButtonWithTitleInView(title, view) {
    if (!view || !view.subviews || !view.subviews()) {
      return undefined
    }
    var subviews = view.subviews()
    for (var i = 0; i < subviews.length; i += 1) {
      var subview = subviews[i]
      if (
        subview.isKindOfClass(nsButtonClass) &&
        String(subview.title()) == title
      ) {
        return subview
      }
      var foundButton = findButtonWithTitleInView(title, subview)
      if (foundButton) {
        return foundButton
      }
    }
    return undefined
  }

  var cancelButton = findButtonWithTitleInView('Cancel', dialog.contentView())
  var okButton = findButtonWithTitleInView(
    options.buttonLabel || 'Open',
    dialog.contentView()
  )

  var delegate = RunDelegate.new()

  cancelButton.setTarget(delegate)
  cancelButton.setAction(NSSelectorFromString('button1Clicked:'))
  okButton.setTarget(delegate)
  okButton.setAction(NSSelectorFromString('button0Clicked:'))

  var fiber
  if (callback) {
    if (coscript.createFiber) {
      fiber = coscript.createFiber()
    } else {
      coscript.shouldKeepAround = true
    }
  }

  delegate.options = NSDictionary.dictionaryWithDictionary({
    onClicked: function handleEnd(returnCode) {
      if (callback) {
        callback(returnCode == 0 ? getURLs() : undefined)
        NSApp.endSheet(dialog)
        if (fiber) {
          fiber.cleanup()
        } else {
          coscript.shouldKeepAround = false
        }
      } else {
        NSApp.stopModalWithCode(returnCode)
      }
    },
  })

  var window = (document.sketchObject || document).documentWindow()
  dialog.beginSheetForDirectory_file_modalForWindow_modalDelegate_didEndSelector_contextInfo(
    null,
    null,
    window,
    null,
    null,
    null
  )

  if (!callback) {
    buttonClicked = NSApp.runModalForWindow(window)
    NSApp.endSheet(dialog)
    if (buttonClicked == 0) {
      return getURLs()
    }
    return undefined
  }

  return undefined
}


/***/ }),

/***/ "./node_modules/@skpm/dialog/lib/run-delegate.js":
/*!*******************************************************!*\
  !*** ./node_modules/@skpm/dialog/lib/run-delegate.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var ObjCClass = __webpack_require__(/*! cocoascript-class */ "./node_modules/cocoascript-class/lib/index.js").default

module.exports = new ObjCClass({
  options: null,

  'buttonClicked:': function handleButtonClicked(sender) {
    if (this.options.onClicked) {
      this.options.onClicked(sender.tag())
    }
    this.release()
  },

  'button0Clicked:': function handleButtonClicked() {
    if (this.options.onClicked) {
      this.options.onClicked(0)
    }
    this.release()
  },

  'button1Clicked:': function handleButtonClicked() {
    if (this.options.onClicked) {
      this.options.onClicked(1)
    }
    this.release()
  },
})


/***/ }),

/***/ "./node_modules/@skpm/dialog/lib/save-dialog.js":
/*!******************************************************!*\
  !*** ./node_modules/@skpm/dialog/lib/save-dialog.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable no-not-accumulator-reassign/no-not-accumulator-reassign */
var RunDelegate = __webpack_require__(/*! ./run-delegate */ "./node_modules/@skpm/dialog/lib/run-delegate.js")
var utils = __webpack_require__(/*! ./utils */ "./node_modules/@skpm/dialog/lib/utils.js")

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowsavedialogbrowserwindow-options-callback
module.exports = function saveDialog(document, options, callback) {
  if (!document || typeof document.class !== 'function') {
    callback = options
    options = document
    document = undefined
  }
  if (!options) {
    options = {}
  }

  var buttonClicked
  var url

  var dialog = NSSavePanel.savePanel()

  if (options.title) {
    dialog.title = options.title
  }

  if (options.defaultPath) {
    // that's a path
    dialog.setDirectoryURL(utils.getURL(options.defaultPath))

    if (
      options.defaultPath[0] === '.' ||
      options.defaultPath[0] === '~' ||
      options.defaultPath[0] === '/'
    ) {
      var parts = options.defaultPath.split('/')
      if (parts.length > 1 && parts[parts.length - 1]) {
        dialog.setNameFieldStringValue(parts[parts.length - 1])
      }
    } else {
      dialog.setNameFieldStringValue(options.defaultPath)
    }
  }

  if (options.buttonLabel) {
    dialog.prompt = options.buttonLabel
  }

  if (options.filters && options.filters.length) {
    var exts = []
    options.filters.forEach(function setFilter(filter) {
      filter.extensions.forEach(function setExtension(ext) {
        exts.push(ext)
      })
    })

    dialog.allowedFileTypes = exts
  }

  if (options.message) {
    dialog.message = options.message
  }

  if (options.nameFieldLabel) {
    dialog.nameFieldLabel = options.nameFieldLabel
  }

  if (options.showsTagField) {
    dialog.showsTagField = options.showsTagField
  }

  if (!document) {
    buttonClicked = dialog.runModal()
    if (buttonClicked == NSOKButton) {
      url = String(dialog.URL().path())

      if (callback) {
        callback(url)
        return undefined
      }
      return url
    }
    return undefined
  }

  var nsButtonClass = NSButton.class()

  function findButtonWithTitleInView(title, view) {
    if (!view || !view.subviews || !view.subviews()) {
      return undefined
    }
    var subviews = view.subviews()
    for (var i = 0; i < subviews.length; i += 1) {
      var subview = subviews[i]
      if (
        subview.isKindOfClass(nsButtonClass) &&
        String(subview.title()) == title
      ) {
        return subview
      }
      var foundButton = findButtonWithTitleInView(title, subview)
      if (foundButton) {
        return foundButton
      }
    }
    return undefined
  }

  var cancelButton = findButtonWithTitleInView('Cancel', dialog.contentView())
  var okButton = findButtonWithTitleInView(
    options.buttonLabel || 'Save',
    dialog.contentView()
  )

  var delegate = RunDelegate.new()

  cancelButton.setTarget(delegate)
  cancelButton.setAction(NSSelectorFromString('button1Clicked:'))
  okButton.setTarget(delegate)
  okButton.setAction(NSSelectorFromString('button0Clicked:'))

  var fiber
  if (callback) {
    if (coscript.createFiber) {
      fiber = coscript.createFiber()
    } else {
      coscript.shouldKeepAround = true
    }
  }

  delegate.options = NSDictionary.dictionaryWithDictionary({
    onClicked: function handleEnd(returnCode) {
      if (callback) {
        callback(returnCode == 0 ? String(dialog.URL().path()) : undefined)
        NSApp.endSheet(dialog)
        if (fiber) {
          fiber.cleanup()
        } else {
          coscript.shouldKeepAround = false
        }
      } else {
        NSApp.stopModalWithCode(returnCode)
      }
    },
  })

  var window = (document.sketchObject || document).documentWindow()
  dialog.beginSheetForDirectory_file_modalForWindow_modalDelegate_didEndSelector_contextInfo(
    null,
    null,
    window,
    null,
    null,
    null
  )

  if (!callback) {
    buttonClicked = NSApp.runModalForWindow(window)
    NSApp.endSheet(dialog)
    if (buttonClicked == 0) {
      return String(dialog.URL().path())
    }
    return undefined
  }

  return undefined
}


/***/ }),

/***/ "./node_modules/@skpm/dialog/lib/utils.js":
/*!************************************************!*\
  !*** ./node_modules/@skpm/dialog/lib/utils.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports.getURL = function getURL(path) {
  return NSURL.URLWithString(
    String(
      NSString.stringWithString(path).stringByExpandingTildeInPath()
    ).replace(/ /g, '%20')
  )
}


/***/ }),

/***/ "./node_modules/@skpm/fs/index.js":
/*!****************************************!*\
  !*** ./node_modules/@skpm/fs/index.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// TODO: async. Should probably be done with NSFileHandle and some notifications
// TODO: file descriptor. Needs to be done with NSFileHandle
var Buffer = __webpack_require__(/*! buffer */ "buffer").Buffer

var ERRORS = {
  'EPERM': {
    message: 'operation not permitted',
    errno: -1
  },
  'ENOENT': {
    message: 'no such file or directory',
    errno: -2
  },
  'EACCES': {
    message: 'permission denied',
    errno: -13
  },
  'ENOTDIR': {
    message: 'not a directory',
    errno: -20
  },
  'EISDIR': {
    message: 'illegal operation on a directory',
    errno: -21
  }
}

function fsError(code, options) {
  var error = new Error(
    code + ': '
    + ERRORS[code].message + ', '
    + (options.syscall || '')
    + (options.path ? ' \'' + options.path + '\'' : '')
  )

  Object.keys(options).forEach(function (k) {
    error[k] = options[k]
  })

  error.code = code
  error.errno = ERRORS[code].errno

  return error
}

function fsErrorForPath(path, shouldBeDir, err, syscall) {
  var fileManager = NSFileManager.defaultManager()
  var doesExist = fileManager.fileExistsAtPath(path)
  if (!doesExist) {
    return fsError('ENOENT', {
      path: path,
      syscall: syscall || 'open'
    })
  }
  var isReadable = fileManager.isReadableFileAtPath(path)
  if (!isReadable) {
    return fsError('EACCES', {
      path: path,
      syscall: syscall || 'open'
    })
  }
  if (typeof shouldBeDir !== 'undefined') {
    var isDirectory = module.exports.lstatSync(path).isDirectory()
    if (isDirectory && !shouldBeDir) {
      return fsError('EISDIR', {
        path: path,
        syscall: syscall || 'read'
      })
    } else if (!isDirectory && shouldBeDir) {
      return fsError('ENOTDIR', {
        path: path,
        syscall: syscall || 'read'
      })
    }
  }
  return new Error(err || ('Unknown error while manipulating ' + path))
}

function encodingFromOptions(options, defaultValue) {
  return options && options.encoding
    ? String(options.encoding)
    : (
      options
        ? String(options)
        : defaultValue
    )
}

module.exports.constants = {
  F_OK: 0,
  R_OK: 4,
  W_OK: 2,
  X_OK: 1
}

module.exports.accessSync = function(path, mode) {
  mode = mode | 0
  var fileManager = NSFileManager.defaultManager()

  switch (mode) {
    case 0:
      canAccess = module.exports.existsSync(path)
      break
    case 1:
      canAccess = Boolean(Number(fileManager.isExecutableFileAtPath(path)))
      break
    case 2:
      canAccess = Boolean(Number(fileManager.isWritableFileAtPath(path)))
      break
    case 3:
      canAccess = Boolean(Number(fileManager.isExecutableFileAtPath(path))) && Boolean(Number(fileManager.isWritableFileAtPath(path)))
      break
    case 4:
      canAccess = Boolean(Number(fileManager.isReadableFileAtPath(path)))
      break
    case 5:
      canAccess = Boolean(Number(fileManager.isReadableFileAtPath(path))) && Boolean(Number(fileManager.isExecutableFileAtPath(path)))
      break
    case 6:
      canAccess = Boolean(Number(fileManager.isReadableFileAtPath(path))) && Boolean(Number(fileManager.isWritableFileAtPath(path)))
      break
    case 7:
      canAccess = Boolean(Number(fileManager.isReadableFileAtPath(path))) && Boolean(Number(fileManager.isWritableFileAtPath(path))) && Boolean(Number(fileManager.isExecutableFileAtPath(path)))
      break
  }

  if (!canAccess) {
    throw new Error('Can\'t access ' + String(path))
  }
}

module.exports.appendFileSync = function(file, data, options) {
  if (!module.exports.existsSync(file)) {
    return module.exports.writeFileSync(file, data, options)
  }

  var handle = NSFileHandle.fileHandleForWritingAtPath(file)
  handle.seekToEndOfFile()

  var encoding = encodingFromOptions(options, 'utf8')

  var nsdata = Buffer.from(data, encoding === 'NSData' || encoding === 'buffer' ? undefined : encoding).toNSData()

  handle.writeData(nsdata)
}

module.exports.chmodSync = function(path, mode) {
  var err = MOPointer.alloc().init()
  var fileManager = NSFileManager.defaultManager()
  fileManager.setAttributes_ofItemAtPath_error({
    NSFilePosixPermissions: mode
  }, path, err)

  if (err.value() !== null) {
    throw fsErrorForPath(path, undefined, err.value())
  }
}

module.exports.copyFileSync = function(path, dest, flags) {
  var err = MOPointer.alloc().init()
  var fileManager = NSFileManager.defaultManager()
  fileManager.copyItemAtPath_toPath_error(path, dest, err)

  if (err.value() !== null) {
    throw fsErrorForPath(path, false, err.value())
  }
}

module.exports.existsSync = function(path) {
  var fileManager = NSFileManager.defaultManager()
  return Boolean(Number(fileManager.fileExistsAtPath(path)))
}

module.exports.linkSync = function(existingPath, newPath) {
  var err = MOPointer.alloc().init()
  var fileManager = NSFileManager.defaultManager()
  fileManager.linkItemAtPath_toPath_error(existingPath, newPath, err)

  if (err.value() !== null) {
    throw fsErrorForPath(existingPath, undefined, err.value())
  }
}

module.exports.mkdirSync = function(path, options) {
  var mode = 0o777
  var recursive = false
  if (options && options.mode) {
    mode = options.mode
  }
  if (options && options.recursive) {
    recursive = options.recursive
  }
  if (typeof options === "number") {
    mode = options
  }
  var err = MOPointer.alloc().init()
  var fileManager = NSFileManager.defaultManager()
  fileManager.createDirectoryAtPath_withIntermediateDirectories_attributes_error(path, recursive, {
    NSFilePosixPermissions: mode
  }, err)

  if (err.value() !== null) {
    throw new Error(err.value())
  }
}

module.exports.mkdtempSync = function(path) {
  function makeid() {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for (var i = 0; i < 6; i++)
      text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
  }
  var tempPath = path + makeid()
  module.exports.mkdirSync(tempPath)
  return tempPath
}

module.exports.readdirSync = function(path) {
  var fileManager = NSFileManager.defaultManager()
  var paths = fileManager.subpathsAtPath(path)
  var arr = []
  for (var i = 0; i < paths.length; i++) {
    arr.push(String(paths[i]))
  }
  return arr
}

module.exports.readFileSync = function(path, options) {
  var encoding = encodingFromOptions(options, 'buffer')
  var fileManager = NSFileManager.defaultManager()
  var data = fileManager.contentsAtPath(path)
  if (!data) {
    throw fsErrorForPath(path, false)
  }

  var buffer = Buffer.from(data)

  if (encoding === 'buffer') {
    return buffer
  } else if (encoding === 'NSData') {
    return buffer.toNSData()
  } else {
    return buffer.toString(encoding)
  }
}

module.exports.readlinkSync = function(path) {
  var err = MOPointer.alloc().init()
  var fileManager = NSFileManager.defaultManager()
  var result = fileManager.destinationOfSymbolicLinkAtPath_error(path, err)

  if (err.value() !== null) {
    throw fsErrorForPath(path, undefined, err.value())
  }

  return String(result)
}

module.exports.realpathSync = function(path) {
  return String(NSString.stringByResolvingSymlinksInPath(path))
}

module.exports.renameSync = function(oldPath, newPath) {
  var err = MOPointer.alloc().init()
  var fileManager = NSFileManager.defaultManager()
  fileManager.moveItemAtPath_toPath_error(oldPath, newPath, err)

  var error = err.value()

  if (error !== null) {
    // if there is already a file, we need to overwrite it
    if (String(error.domain()) === 'NSCocoaErrorDomain' && Number(error.code()) === 516) {
      var err2 = MOPointer.alloc().init()
      fileManager.replaceItemAtURL_withItemAtURL_backupItemName_options_resultingItemURL_error(NSURL.fileURLWithPath(newPath), NSURL.fileURLWithPath(oldPath), null, NSFileManagerItemReplacementUsingNewMetadataOnly, null, err2)
      if (err2.value() !== null) {
        throw fsErrorForPath(oldPath, undefined, err2.value())
      }
    } else {
      throw fsErrorForPath(oldPath, undefined, error)
    }
  }
}

module.exports.rmdirSync = function(path) {
  var err = MOPointer.alloc().init()
  var fileManager = NSFileManager.defaultManager()
  var isDirectory = module.exports.lstatSync(path).isDirectory()
  if (!isDirectory) {
    throw fsError('ENOTDIR', {
      path: path,
      syscall: 'rmdir'
    })
  }
  fileManager.removeItemAtPath_error(path, err)

  if (err.value() !== null) {
    throw fsErrorForPath(path, true, err.value(), 'rmdir')
  }
}

function parseStat(result) {
  return {
    dev: String(result.NSFileDeviceIdentifier),
    // ino: 48064969, The file system specific "Inode" number for the file.
    mode: result.NSFileType | result.NSFilePosixPermissions,
    nlink: Number(result.NSFileReferenceCount),
    uid: String(result.NSFileOwnerAccountID),
    gid: String(result.NSFileGroupOwnerAccountID),
    // rdev: 0, A numeric device identifier if the file is considered "special".
    size: Number(result.NSFileSize),
    // blksize: 4096, The file system block size for i/o operations.
    // blocks: 8, The number of blocks allocated for this file.
    atimeMs: Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000,
    mtimeMs: Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000,
    ctimeMs: Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000,
    birthtimeMs: Number(result.NSFileCreationDate.timeIntervalSince1970()) * 1000,
    atime: new Date(Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000 + 0.5), // the 0.5 comes from the node source. Not sure why it's added but in doubt...
    mtime: new Date(Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000 + 0.5),
    ctime: new Date(Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000 + 0.5),
    birthtime: new Date(Number(result.NSFileCreationDate.timeIntervalSince1970()) * 1000 + 0.5),
    isBlockDevice: function() { return result.NSFileType === NSFileTypeBlockSpecial },
    isCharacterDevice: function() { return result.NSFileType === NSFileTypeCharacterSpecial },
    isDirectory: function() { return result.NSFileType === NSFileTypeDirectory },
    isFIFO: function() { return false },
    isFile: function() { return result.NSFileType === NSFileTypeRegular },
    isSocket: function() { return result.NSFileType === NSFileTypeSocket },
    isSymbolicLink: function() { return result.NSFileType === NSFileTypeSymbolicLink },
  }
}

module.exports.lstatSync = function(path) {
  var err = MOPointer.alloc().init()
  var fileManager = NSFileManager.defaultManager()
  var result = fileManager.attributesOfItemAtPath_error(path, err)

  if (err.value() !== null) {
    throw fsErrorForPath(path, undefined, err.value())
  }

  return parseStat(result)
}

// the only difference with lstat is that we resolve symlinks
//
// > lstat() is identical to stat(), except that if pathname is a symbolic
// > link, then it returns information about the link itself, not the file
// > that it refers to.
// http://man7.org/linux/man-pages/man2/lstat.2.html
module.exports.statSync = function(path) {
  return module.exports.lstatSync(module.exports.realpathSync(path))
}

module.exports.symlinkSync = function(target, path) {
  var err = MOPointer.alloc().init()
  var fileManager = NSFileManager.defaultManager()
  var result = fileManager.createSymbolicLinkAtPath_withDestinationPath_error(path, target, err)

  if (err.value() !== null) {
    throw new Error(err.value())
  }
}

module.exports.truncateSync = function(path, len) {
  var hFile = NSFileHandle.fileHandleForUpdatingAtPath(sFilePath)
  hFile.truncateFileAtOffset(len || 0)
  hFile.closeFile()
}

module.exports.unlinkSync = function(path) {
  var err = MOPointer.alloc().init()
  var fileManager = NSFileManager.defaultManager()
  var isDirectory = module.exports.lstatSync(path).isDirectory()
  if (isDirectory) {
    throw fsError('EPERM', {
      path: path,
      syscall: 'unlink'
    })
  }
  var result = fileManager.removeItemAtPath_error(path, err)

  if (err.value() !== null) {
    throw fsErrorForPath(path, false, err.value())
  }
}

module.exports.utimesSync = function(path, aTime, mTime) {
  var err = MOPointer.alloc().init()
  var fileManager = NSFileManager.defaultManager()
  var result = fileManager.setAttributes_ofItemAtPath_error({
    NSFileModificationDate: aTime
  }, path, err)

  if (err.value() !== null) {
    throw fsErrorForPath(path, undefined, err.value())
  }
}

module.exports.writeFileSync = function(path, data, options) {
  var encoding = encodingFromOptions(options, 'utf8')

  var nsdata = Buffer.from(
    data, encoding === 'NSData' || encoding === 'buffer' ? undefined : encoding
  ).toNSData()

  nsdata.writeToFile_atomically(path, true)
}


/***/ }),

/***/ "./node_modules/cocoascript-class/lib/index.js":
/*!*****************************************************!*\
  !*** ./node_modules/cocoascript-class/lib/index.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SuperCall = undefined;
exports.default = ObjCClass;

var _runtime = __webpack_require__(/*! ./runtime.js */ "./node_modules/cocoascript-class/lib/runtime.js");

exports.SuperCall = _runtime.SuperCall;

// super when returnType is id and args are void
// id objc_msgSendSuper(struct objc_super *super, SEL op, void)

const SuperInit = (0, _runtime.SuperCall)(NSStringFromSelector("init"), [], { type: "@" });

// Returns a real ObjC class. No need to use new.
function ObjCClass(defn) {
  const superclass = defn.superclass || NSObject;
  const className = (defn.className || defn.classname || "ObjCClass") + NSUUID.UUID().UUIDString();
  const reserved = new Set(['className', 'classname', 'superclass']);
  var cls = MOClassDescription.allocateDescriptionForClassWithName_superclass_(className, superclass);
  // Add each handler to the class description
  const ivars = [];
  for (var key in defn) {
    const v = defn[key];
    if (typeof v == 'function' && key !== 'init') {
      var selector = NSSelectorFromString(key);
      cls.addInstanceMethodWithSelector_function_(selector, v);
    } else if (!reserved.has(key)) {
      ivars.push(key);
      cls.addInstanceVariableWithName_typeEncoding(key, "@");
    }
  }

  cls.addInstanceMethodWithSelector_function_(NSSelectorFromString('init'), function () {
    const self = SuperInit.call(this);
    ivars.map(name => {
      Object.defineProperty(self, name, {
        get() {
          return getIvar(self, name);
        },
        set(v) {
          (0, _runtime.object_setInstanceVariable)(self, name, v);
        }
      });
      self[name] = defn[name];
    });
    // If there is a passsed-in init funciton, call it now.
    if (typeof defn.init == 'function') defn.init.call(this);
    return self;
  });

  return cls.registerClass();
};

function getIvar(obj, name) {
  const retPtr = MOPointer.new();
  (0, _runtime.object_getInstanceVariable)(obj, name, retPtr);
  return retPtr.value().retain().autorelease();
}

/***/ }),

/***/ "./node_modules/cocoascript-class/lib/runtime.js":
/*!*******************************************************!*\
  !*** ./node_modules/cocoascript-class/lib/runtime.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SuperCall = SuperCall;
exports.CFunc = CFunc;
const objc_super_typeEncoding = '{objc_super="receiver"@"super_class"#}';

// You can store this to call your function. this must be bound to the current instance.
function SuperCall(selector, argTypes, returnType) {
  const func = CFunc("objc_msgSendSuper", [{ type: '^' + objc_super_typeEncoding }, { type: ":" }, ...argTypes], returnType);
  return function (...args) {
    const struct = make_objc_super(this, this.superclass());
    const structPtr = MOPointer.alloc().initWithValue_(struct);
    return func(structPtr, selector, ...args);
  };
}

// Recursively create a MOStruct
function makeStruct(def) {
  if (typeof def !== 'object' || Object.keys(def).length == 0) {
    return def;
  }
  const name = Object.keys(def)[0];
  const values = def[name];

  const structure = MOStruct.structureWithName_memberNames_runtime(name, Object.keys(values), Mocha.sharedRuntime());

  Object.keys(values).map(member => {
    structure[member] = makeStruct(values[member]);
  });

  return structure;
}

function make_objc_super(self, cls) {
  return makeStruct({
    objc_super: {
      receiver: self,
      super_class: cls
    }
  });
}

// Due to particularities of the JS bridge, we can't call into MOBridgeSupport objects directly
// But, we can ask key value coding to do the dirty work for us ;)
function setKeys(o, d) {
  const funcDict = NSMutableDictionary.dictionary();
  funcDict.o = o;
  Object.keys(d).map(k => funcDict.setValue_forKeyPath(d[k], "o." + k));
}

// Use any C function, not just ones with BridgeSupport
function CFunc(name, args, retVal) {
  function makeArgument(a) {
    if (!a) return null;
    const arg = MOBridgeSupportArgument.alloc().init();
    setKeys(arg, {
      type64: a.type
    });
    return arg;
  }
  const func = MOBridgeSupportFunction.alloc().init();
  setKeys(func, {
    name: name,
    arguments: args.map(makeArgument),
    returnValue: makeArgument(retVal)
  });
  return func;
}

/*
@encode(char*) = "*"
@encode(id) = "@"
@encode(Class) = "#"
@encode(void*) = "^v"
@encode(CGRect) = "{CGRect={CGPoint=dd}{CGSize=dd}}"
@encode(SEL) = ":"
*/

function addStructToBridgeSupport(key, structDef) {
  // OK, so this is probably the nastiest hack in this file.
  // We go modify MOBridgeSupportController behind its back and use kvc to add our own definition
  // There isn't another API for this though. So the only other way would be to make a real bridgesupport file.
  const symbols = MOBridgeSupportController.sharedController().valueForKey('symbols');
  if (!symbols) throw Error("Something has changed within bridge support so we can't add our definitions");
  // If someone already added this definition, don't re-register it.
  if (symbols[key] !== null) return;
  const def = MOBridgeSupportStruct.alloc().init();
  setKeys(def, {
    name: key,
    type: structDef.type
  });
  symbols[key] = def;
};

// This assumes the ivar is an object type. Return value is pretty useless.
const object_getInstanceVariable = exports.object_getInstanceVariable = CFunc("object_getInstanceVariable", [{ type: "@" }, { type: '*' }, { type: "^@" }], { type: "^{objc_ivar=}" });
// Again, ivar is of object type
const object_setInstanceVariable = exports.object_setInstanceVariable = CFunc("object_setInstanceVariable", [{ type: "@" }, { type: '*' }, { type: "@" }], { type: "^{objc_ivar=}" });

// We need Mocha to understand what an objc_super is so we can use it as a function argument
addStructToBridgeSupport('objc_super', { type: objc_super_typeEncoding });

/***/ }),

/***/ "./src/aco-to-colors.js":
/*!******************************!*\
  !*** ./src/aco-to-colors.js ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch */ "sketch");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var buffer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! buffer */ "buffer");
/* harmony import */ var buffer__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(buffer__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! path */ "path");
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _skpm_fs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @skpm/fs */ "./node_modules/@skpm/fs/index.js");
/* harmony import */ var _skpm_fs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_skpm_fs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _color__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./color */ "./src/color.js");





/**
 * Convert Adobe color swatch (ACO) file to NSColorList
 * File format specification:
 * https://www.adobe.com/devnet-apps/photoshop/fileformatashtml/#50577411_pgfId-1055819
 * http://www.nomodes.com/aco.html
 * @param  {String} filePath
 * @returns {NSColorList}
 */

/* harmony default export */ __webpack_exports__["default"] = (function (filePath) {
  var colorContents = Object(_skpm_fs__WEBPACK_IMPORTED_MODULE_3__["readFileSync"])(filePath);
  var colorBuffer = buffer__WEBPACK_IMPORTED_MODULE_1__["Buffer"].from(colorContents);

  if (colorBuffer.length < 4) {
    sketch__WEBPACK_IMPORTED_MODULE_0__["UI"].message('Error: Not a Adobe color swatch (ACO) file.');
    return;
  }

  var version = colorBuffer.slice(0, 2).readUInt16BE(0);
  var count = colorBuffer.slice(2, 4).readUInt16BE(0);
  var name = Object(path__WEBPACK_IMPORTED_MODULE_2__["basename"])(filePath, '.aco');
  var colors = NSColorList.alloc().initWithName(name);
  var keyCount = {}; // version 1

  var i;

  if (version === 1 && (colorBuffer.length - 4) / 10 === count) {
    i = 4;

    while (i < colorBuffer.length) {
      var colorSpace = colorBuffer.slice(i, i + 2).readUInt16BE(0);
      var w = colorBuffer.slice(i + 2, i + 4).readUInt16BE(0);
      var x = colorBuffer.slice(i + 4, i + 6).readUInt16BE(0);
      var y = colorBuffer.slice(i + 6, i + 8).readUInt16BE(0);
      var z = colorBuffer.slice(i + 8, i + 10).readUInt16BE(0);
      var nscolor = _color__WEBPACK_IMPORTED_MODULE_4__["default"].colorFromAco(colorSpace, w, x, y, z);
      var colorName = _color__WEBPACK_IMPORTED_MODULE_4__["default"].toHexValue(nscolor);
      _color__WEBPACK_IMPORTED_MODULE_4__["default"].addColorToList(nscolor, colorName, colors, keyCount);
      i += 10;
    }
  } // version 2


  if (version === 2 || version === 1 && colorBuffer.length > count * 10 + 8 && colorBuffer.slice(4 + count * 10, 6 + count * 10).readUInt16BE(0) === 2 && colorBuffer.slice(6 + count * 10, 8 + count * 10).readUInt16BE(0) === count) {
    i = 4 + count * 10 + 4;

    if (version === 2) {
      i = 4;
    }

    while (i < colorBuffer.length) {
      var _colorSpace = colorBuffer.slice(i, i + 2).readUInt16BE(0);

      var _w = colorBuffer.slice(i + 2, i + 4).readUInt16BE(0);

      var _x = colorBuffer.slice(i + 4, i + 6).readUInt16BE(0);

      var _y = colorBuffer.slice(i + 6, i + 8).readUInt16BE(0);

      var _z = colorBuffer.slice(i + 8, i + 10).readUInt16BE(0);

      var _colorName = '';
      var nameLength = colorBuffer.slice(i + 12, i + 14).readUInt16BE(0);

      for (var j = 0; j < nameLength * 2 - 2; j += 2) {
        _colorName += String.fromCodePoint(colorBuffer.slice(i + 14 + j, i + 16 + j).readUInt16BE(0));
      }

      var _nscolor = _color__WEBPACK_IMPORTED_MODULE_4__["default"].colorFromAco(_colorSpace, _w, _x, _y, _z);

      _color__WEBPACK_IMPORTED_MODULE_4__["default"].addColorToList(_nscolor, _colorName, colors, keyCount);
      i += 14 + nameLength * 2;
    }
  }

  return colors;
});

/***/ }),

/***/ "./src/ase-to-colors.js":
/*!******************************!*\
  !*** ./src/ase-to-colors.js ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch */ "sketch");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var buffer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! buffer */ "buffer");
/* harmony import */ var buffer__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(buffer__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! path */ "path");
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _skpm_fs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @skpm/fs */ "./node_modules/@skpm/fs/index.js");
/* harmony import */ var _skpm_fs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_skpm_fs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _color__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./color */ "./src/color.js");





/**
 * Convert Adobe Swatch Exchange (ASE) file to NSColorList
 * File format specification:
 * http://www.selapa.net/swatches/colors/fileformats.php#adobe_ase
 * @param  {String} filePath
 * @returns {NSColorList}
 */

/* harmony default export */ __webpack_exports__["default"] = (function (filePath) {
  var colorContents = Object(_skpm_fs__WEBPACK_IMPORTED_MODULE_3__["readFileSync"])(filePath);
  var colorBuffer = buffer__WEBPACK_IMPORTED_MODULE_1__["Buffer"].from(colorContents);
  var signature = colorBuffer.toString('utf-8', 0, 4);
  var versionMajor = colorBuffer.slice(4, 6).readInt16BE(0);
  var versionMin = colorBuffer.slice(6, 8).readInt16BE(0);
  var count = colorBuffer.slice(8, 12).readInt32BE(0);

  if (colorBuffer.length > 12 && signature !== 'ASEF' && versionMajor !== 1 && versionMin !== 0) {
    sketch__WEBPACK_IMPORTED_MODULE_0__["UI"].message('Error: Not Adobe Swatch Exchange (ASE) file.');
    return;
  }

  var name = Object(path__WEBPACK_IMPORTED_MODULE_2__["basename"])(filePath, '.ase');
  var colors = NSColorList.alloc().initWithName(name);
  var keyCount = {};
  var i = 12;

  while (i < colorBuffer.length) {
    var blockLength = void 0;
    var blockType = colorBuffer.slice(i, i + 2).readInt16BE(0).toString(16);
    i += 2; // Ignore group start c001, end c002

    if (blockType === 'c001') {
      blockLength = colorBuffer.slice(i, i + 4).readInt32BE(0);
      i += blockLength;
    }

    if (blockType === 'c002') {
      i += 2;
    } // Color entry, start 0001


    if (blockType === '1') {
      blockLength = colorBuffer.slice(i, i + 4).readInt32BE(0);
      var nameLength = colorBuffer.slice(i + 4, i + 6).readUInt16BE(0);
      var colorName = '';

      for (var j = 0; j < nameLength * 2 - 2; j += 2) {
        colorName += String.fromCodePoint(colorBuffer.slice(i + 6 + j, i + 8 + j).readInt16BE(0));
      }

      var _i = i + 6 + nameLength * 2;

      var colorModel = colorBuffer.slice(_i, _i + 4).toString('utf-8', 0, 4);
      _i += 4;

      if (colorModel === 'RGB ') {
        var r = colorBuffer.slice(_i, _i + 4).readFloatBE(0);
        _i += 4;
        var g = colorBuffer.slice(_i, _i + 4).readFloatBE(0);
        _i += 4;
        var b = colorBuffer.slice(_i, _i + 4).readFloatBE(0);
        var nscolor = _color__WEBPACK_IMPORTED_MODULE_4__["default"].colorWithRGBA(r * 255, g * 255, b * 255, 1.0);
        _color__WEBPACK_IMPORTED_MODULE_4__["default"].addColorToList(nscolor, colorName, colors, keyCount);
      } else if (colorModel === 'CMYK') {
        var c = colorBuffer.slice(_i, _i + 4).readFloatBE(0);
        _i += 4;
        var m = colorBuffer.slice(_i, _i + 4).readFloatBE(0);
        _i += 4;
        var y = colorBuffer.slice(_i, _i + 4).readFloatBE(0);
        _i += 4;
        var k = colorBuffer.slice(_i, _i + 4).readInt32BE(0);

        var _nscolor = _color__WEBPACK_IMPORTED_MODULE_4__["default"].colorWithCMYKA(c * 100, m * 100, y * 100, k * 100, 1.0);

        _color__WEBPACK_IMPORTED_MODULE_4__["default"].addColorToList(_nscolor, colorName, colors, keyCount);
      } else if (colorModel === 'LAB ') {
        var l = colorBuffer.slice(_i, _i + 4).readFloatBE(0);
        _i += 4;
        var a = colorBuffer.slice(_i, _i + 4).readFloatBE(0);
        _i += 4;

        var _b = colorBuffer.slice(_i, _i + 4).readFloatBE(0);

        var _nscolor2 = _color__WEBPACK_IMPORTED_MODULE_4__["default"].colorWithLABA(l * 100, a * 100, _b * 100, 1.0);

        _color__WEBPACK_IMPORTED_MODULE_4__["default"].addColorToList(_nscolor2, colorName, colors, keyCount);
      } else if (colorModel === 'Gray') {
        var _g = colorBuffer.slice(_i, _i + 4).readFloatBE(0);

        var _nscolor3 = _color__WEBPACK_IMPORTED_MODULE_4__["default"].colorWithGA((1 - _g) * 100, 1.0);

        _color__WEBPACK_IMPORTED_MODULE_4__["default"].addColorToList(_nscolor3, colorName, colors, keyCount);
      }

      i += blockLength;
    }
  }

  return colors;
});

/***/ }),

/***/ "./src/clr-to-colors.js":
/*!******************************!*\
  !*** ./src/clr-to-colors.js ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! path */ "path");
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_0__);

/**
 * Read Apple CLR file
 * @param  {String} filePath
 * @returns {NSColorList}
 */

/* harmony default export */ __webpack_exports__["default"] = (function (filePath) {
  var name = Object(path__WEBPACK_IMPORTED_MODULE_0__["basename"])(filePath, '.clr');
  var colors = NSColorList.alloc().initWithName_fromFile(name, filePath);
  return colors;
});

/***/ }),

/***/ "./src/color.js":
/*!**********************!*\
  !*** ./src/color.js ***!
  \**********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  /**
   * @param  {Number} r 0..255
   * @param  {Number} g 0..255
   * @param  {Number} b 0..255
   * @param  {Number} a 0..1
   * @returns {NSColor}
   */
  colorWithRGBA: function colorWithRGBA(r, g, b, a) {
    return NSColor.colorWithRed_green_blue_alpha(r / 255, g / 255, b / 255, a);
  },

  /**
   * @param  {Number} h 0..360
   * @param  {Number} s 0..100
   * @param  {Number} b 0..100
   * @param  {Number} a 0..1
   * @returns {NSColor}
   */
  colorWithHSBA: function colorWithHSBA(h, s, b, a) {
    return NSColor.colorWithHue_saturation_brightness_alpha(h / 360, s / 100, b / 100, a);
  },

  /**
   * @param  {Number} c 0..100
   * @param  {Number} m 0..100
   * @param  {Number} y 0..100
   * @param  {Number} k 0..100
   * @param  {Number} a 0..1
   * @returns {NSColor}
   */
  colorWithCMYKA: function colorWithCMYKA(c, m, y, k, a) {
    return NSColor.colorWithDeviceCyan_magenta_yellow_black_alpha(c / 100, m / 100, y / 100, k / 100, a);
  },

  /**
   * http://www.easyrgb.com/en/math.php
   * @param  {Number} l 0..100
   * @param  {Number} a -128..127
   * @param  {Number} b -128..127
   * @param  {Number} alpha 0..1
   * @returns {NSColor}
   */
  colorWithLABA: function colorWithLABA(l, a, b, alpha) {
    // CIE lab to CIE XYZ
    var y = (l + 16) / 116;
    var x = a / 500 + y;
    var z = y - b / 200;
    y = y * y * y > 0.008856 ? y * y * y : (y - 16 / 116) / 7.787;
    x = x * x * x > 0.008856 ? x * x * x : (x - 16 / 116) / 7.787;
    z = z * z * z > 0.008856 ? z * z * z : (z - 16 / 116) / 7.787; // D65

    x = x * 95.047;
    y = y * 100;
    z = z * 108.883; // CIE XYZ to sRGB

    x = x / 100;
    y = y / 100;
    z = z / 100;
    var R = x * 3.2406 + y * -1.5372 + z * -0.4986;
    var G = x * -0.9689 + y * 1.8758 + z * 0.0415;
    var B = x * 0.0557 + y * -0.2040 + z * 1.0570;
    R = R > 0.0031308 ? 1.055 * Math.pow(R, 1 / 2.4) - 0.055 : 12.92 * R;
    G = G > 0.0031308 ? 1.055 * Math.pow(G, 1 / 2.4) - 0.055 : 12.92 * G;
    B = B > 0.0031308 ? 1.055 * Math.pow(B, 1 / 2.4) - 0.055 : 12.92 * B;
    return NSColor.colorWithRed_green_blue_alpha(R, G, B, alpha);
  },

  /**
   * @param  {Number} g grayscale 0..100 white..black
   * @param  {Number} a 0..1
   * @returns {NSColor}
   */
  colorWithGA: function colorWithGA(g, a) {
    return NSColor.colorWithWhite_alpha(1 - g / 100, a);
  },

  /**
   * http://www.nomodes.com/aco.html
   * @param  {Number} colorSpace 0: RGB, 1: HSB, 2: CMYK, 7: LAB, 8: Grayscale, 9, Wide CMYK
   * @param  {Number} w
   * @param  {Number} x
   * @param  {Number} y
   * @param  {Number} z
   * @returns {NSColor}
   */
  colorFromAco: function colorFromAco(colorSpace, w, x, y, z) {
    if (colorSpace === 0) {
      // w: 0..65535, x: 0..65535, y: 0..65535, z: 0
      return this.colorWithRGBA(w / 65535 * 255, x / 65535 * 255, y / 65535 * 255, 1.0);
    } else if (colorSpace === 1) {
      // w: 0..65535, x: 0..65535, y: 0..65535, z: 0
      return this.colorWithHSBA(w / 65535 * 360, x / 65535 * 100, y / 65535 * 100, 1.0);
    } else if (colorSpace === 2) {
      // w: 0..65535, x: 0..65535, y: 0..65535, z: 0..65535
      return this.colorWithCMYKA(100 - w / 65535 * 100, 100 - x / 65535 * 100, 100 - y / 65535 * 100, 100 - z / 65535 * 100, 1.0);
    } else if (colorSpace === 7) {
      // w: 0..10000, x: -12800..12700, y: -12800..12700, z: 0
      return this.colorWithLABA(w / 100, x / 100, y / 100, 1.0);
    } else if (colorSpace === 8) {
      // w: 0..10000, x: 0, y: 0, z: 0
      return this.colorWithGA(w / 10000 * 100, 1.0);
    } else if (colorSpace === 9) {
      // w: 0..10000, x: 0..10000, y: 0..10000, z: 0..10000
      return this.colorWithCMYKA(w / 10000 * 100, x / 10000 * 100, y / 10000 * 100, z / 10000 * 100, 1.0);
    } else {
      return null;
    }
  },

  /**
   * @param  {NSColor} nscolor
   * @param  {String} key
   * @param  {NSColorList} colorList
   * @param  {Object} keyCount
   */
  addColorToList: function addColorToList(nscolor, key, colorList, keyCount) {
    if (keyCount[key]) {
      keyCount[key]++;
    } else {
      keyCount[key] = 1;
    }

    if (keyCount[key] === 1) {
      colorList.setColor_forKey(nscolor, key);
    } else if (keyCount[key] === 2) {
      colorList.setColor_forKey(nscolor, key + ' Copy');
    } else {
      colorList.setColor_forKey(nscolor, key + ' Copy ' + (keyCount[key] - 1));
    }
  },

  /**
   * @param  {NSColor} nscolor
   * @returns {String}
   */
  toHexValue: function toHexValue(nscolor) {
    var color = MSColor.colorWithNSColor(nscolor);
    return String(color.immutableModelObject().hexValue());
  },

  /**
   * @param  {NSColorList} colorList
   * @returns {Object}
   */
  toObject: function toObject(colorList) {
    var _this = this;

    var colors = {
      name: colorList.name(),
      items: []
    };
    colorList.allKeys().forEach(function (key) {
      var color = colorList.colorWithKey(key);
      colors.items.push({
        name: key,
        hex: '#' + String(_this.toHexValue(color)) // rgba: {},
        // nscolor: {
        //     red: parseFloat(color.redComponent()).toFixed(3),
        //     green: parseFloat(color.greenComponent()).toFixed(3),
        //     blue: parseFloat(color.blueComponent()).toFixed(3),
        //     alpha: parseFloat(color.alphaComponent()).toFixed(2),
        // }

      });
    });
    return colors;
  }
});

/***/ }),

/***/ "./src/gpl-to-colors.js":
/*!******************************!*\
  !*** ./src/gpl-to-colors.js ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch */ "sketch");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var os__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! os */ "os");
/* harmony import */ var os__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(os__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _skpm_fs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @skpm/fs */ "./node_modules/@skpm/fs/index.js");
/* harmony import */ var _skpm_fs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_skpm_fs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _color__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./color */ "./src/color.js");




/**
 * Convert GIMP palette file to NSColorList
 * http://www.selapa.net/swatches/colors/fileformats.php#gimp_gpl
 * @param  {String} filePath
 * @returns {NSColorList}
 */

/* harmony default export */ __webpack_exports__["default"] = (function (filePath) {
  var colorContents = Object(_skpm_fs__WEBPACK_IMPORTED_MODULE_2__["readFileSync"])(filePath, 'utf-8');
  var lines = colorContents.split(os__WEBPACK_IMPORTED_MODULE_1__["EOL"]);

  if (lines.length < 2 && lines[0] !== 'GIMP Palette') {
    sketch__WEBPACK_IMPORTED_MODULE_0__["UI"].message('Error: not a GIMP palette file.');
    return;
  }

  var name = lines[1].replace(/Name:[\t|\s]*/, '');
  var colors = NSColorList.alloc().initWithName(name);
  var keyCount = {};
  lines.forEach(function (line) {
    var regExpColor = new RegExp(/(\d+)[\t|\s]+(\d+)[\t|\s]+(\d+)[\t|\s]+(.*)/, '');

    if (regExpColor.test(line)) {
      var r = parseInt(line.match(regExpColor)[1]);
      var g = parseInt(line.match(regExpColor)[2]);
      var b = parseInt(line.match(regExpColor)[3]);
      var _name = line.match(regExpColor)[4];
      var nscolor = _color__WEBPACK_IMPORTED_MODULE_3__["default"].colorWithRGBA(r, g, b, 1.0);
      _color__WEBPACK_IMPORTED_MODULE_3__["default"].addColorToList(nscolor, _name, colors, keyCount);
    }
  });
  return colors;
});

/***/ }),

/***/ "./src/main.js":
/*!*********************!*\
  !*** ./src/main.js ***!
  \*********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch */ "sketch");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _skpm_dialog__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @skpm/dialog */ "./node_modules/@skpm/dialog/lib/index.js");
/* harmony import */ var _skpm_dialog__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_skpm_dialog__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! path */ "path");
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _color__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./color */ "./src/color.js");
/* harmony import */ var _clr_to_colors__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./clr-to-colors */ "./src/clr-to-colors.js");
/* harmony import */ var _gpl_to_colors__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./gpl-to-colors */ "./src/gpl-to-colors.js");
/* harmony import */ var _aco_to_colors__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./aco-to-colors */ "./src/aco-to-colors.js");
/* harmony import */ var _ase_to_colors__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./ase-to-colors */ "./src/ase-to-colors.js");








/* harmony default export */ __webpack_exports__["default"] = (function () {
  _skpm_dialog__WEBPACK_IMPORTED_MODULE_1___default.a.showOpenDialog({
    filters: [{
      name: 'Apple Color Picker Palette',
      extensions: ['clr']
    }, {
      name: 'Adobe Color Swatch',
      extensions: ['aco']
    }, {
      name: 'Adobe Swatch Exchange',
      extensions: ['ase']
    }, {
      name: 'GIMP Palette',
      extensions: ['gpl']
    }],
    properties: ['openFile']
  }, function (filePaths) {
    var colors;
    var filePath = filePaths[0];
    var fileType = Object(path__WEBPACK_IMPORTED_MODULE_2__["extname"])(filePath).toLowerCase();

    if (fileType === '.clr') {
      colors = Object(_clr_to_colors__WEBPACK_IMPORTED_MODULE_4__["default"])(filePath);
    } else if (fileType === '.aco') {
      colors = Object(_aco_to_colors__WEBPACK_IMPORTED_MODULE_6__["default"])(filePath);
    } else if (fileType === '.ase') {
      colors = Object(_ase_to_colors__WEBPACK_IMPORTED_MODULE_7__["default"])(filePath);
    } else if (fileType === '.gpl') {
      colors = Object(_gpl_to_colors__WEBPACK_IMPORTED_MODULE_5__["default"])(filePath);
    }

    console.log(context.command.identifier());
    console.log(colors.name());
    console.log(_color__WEBPACK_IMPORTED_MODULE_3__["default"].toObject(colors));
  });
});

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("buffer");

/***/ }),

/***/ "os":
/*!*********************!*\
  !*** external "os" ***!
  \*********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("os");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("path");

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ })

/******/ });
  if (key === 'default' && typeof exports === 'function') {
    exports(context);
  } else {
    exports[key](context);
  }
}
that['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=main.js.map